create definer = root@localhost view foodlist as
select `quanlydattiec`.`orderdetails`.`OrderID` AS `id`,
       `quanlydattiec`.`food`.`FoodID`          AS `FoodID`,
       `quanlydattiec`.`food`.`FoodName`        AS `FoodName`,
       `quanlydattiec`.`food`.`Unitprice`       AS `Unitprice`,
       `quanlydattiec`.`food`.`categoryID`      AS `categoryID`,
       `quanlydattiec`.`food`.`Notes`           AS `Notes`
from (`quanlydattiec`.`orderdetails` join `quanlydattiec`.`food`
      on ((`quanlydattiec`.`orderdetails`.`FoodID` = `quanlydattiec`.`food`.`FoodID`)));

