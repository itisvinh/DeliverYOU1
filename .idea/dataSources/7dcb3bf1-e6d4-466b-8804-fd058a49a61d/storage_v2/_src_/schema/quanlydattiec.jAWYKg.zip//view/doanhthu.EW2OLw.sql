create definer = root@localhost view doanhthu as
select `quanlydattiec`.`hoadon`.`PartyDay`        AS `partyday`,
       `quanlydattiec`.`orders`.`paid`            AS `paid`,
       month(`quanlydattiec`.`hoadon`.`PartyDay`) AS `tháng`,
       year(`quanlydattiec`.`hoadon`.`PartyDay`)  AS `năm`,
       count(`quanlydattiec`.`hoadon`.`OrderID`)  AS `số lượng tiệc`,
       curdate()                                  AS `CURDATE()`,
       sum(`quanlydattiec`.`hoadon`.`UnitPrice`)  AS `doanh thu`
from (`quanlydattiec`.`hoadon` join `quanlydattiec`.`orders`
      on ((`quanlydattiec`.`hoadon`.`OrderID` = `quanlydattiec`.`orders`.`OrderID`)));

