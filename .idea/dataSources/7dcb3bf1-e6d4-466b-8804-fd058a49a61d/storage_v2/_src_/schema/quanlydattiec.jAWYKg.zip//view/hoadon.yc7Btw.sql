create definer = root@localhost view hoadon as
select `quanlydattiec`.`orderdetails`.`OrderID`      AS `OrderID`,
       `quanlydattiec`.`sanhcuoi`.`SanhCuoiName`     AS `sanhcuoiname`,
       `quanlydattiec`.`orderdetails`.`PartyDay`     AS `PartyDay`,
       `quanlydattiec`.`orderdetails`.`RentalPeriod` AS `RentalPeriod`,
       `quanlydattiec`.`orderdetails`.`soBan`        AS `soBan`,
       `quanlydattiec`.`orderdetails`.`UnitPrice`    AS `UnitPrice`,
       `quanlydattiec`.`orderdetails`.`Discount`     AS `Discount`
from (`quanlydattiec`.`orderdetails` join `quanlydattiec`.`sanhcuoi`
      on ((`quanlydattiec`.`orderdetails`.`SanhCuoiID` = `quanlydattiec`.`sanhcuoi`.`SanhCuoiID`)))
group by `quanlydattiec`.`orderdetails`.`OrderID`;

