create definer = root@localhost view servicelist as
select `quanlydattiec`.`orderdetails`.`OrderID` AS `id`,
       `quanlydattiec`.`services`.`serviceID`   AS `serviceID`,
       `quanlydattiec`.`services`.`serviceName` AS `serviceName`,
       `quanlydattiec`.`services`.`unitPrice`   AS `unitPrice`
from (`quanlydattiec`.`orderdetails` join `quanlydattiec`.`services`
      on ((`quanlydattiec`.`orderdetails`.`ServiceID` = `quanlydattiec`.`services`.`serviceID`)));

