create
    definer = root@localhost procedure IsTonTaiSDT(IN sdt varchar(45), OUT sl int)
BEGIN
	SELECT COUNT(*) into sl FROM khachhang WHERE SDT = sdt;
END;

